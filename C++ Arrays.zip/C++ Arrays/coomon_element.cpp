// to find commom elemnt in an array

#include <bits/stdc++.h>
using namespace std;

int main()
{
    int arr1[] = {1, 2, 2, 3, 5};
    int arr2[] = { 5, 6, 7, 3, 2};

    int n = sizeof(arr1) / sizeof(arr1[0]);

    int m = sizeof(arr2) / sizeof(arr2[0]);

    // sorting the arrays
    sort(arr1, arr1 + n);
    sort(arr2, arr2 + m);

    vector<int> v;

    set_intersection(arr1, arr1 + n, arr2, arr2 + m, back_inserter(v));

    for (auto i : v)
    {
        cout << i << " ";
    }
}