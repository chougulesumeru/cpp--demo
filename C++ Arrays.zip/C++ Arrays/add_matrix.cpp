// add two matrix

#include <bits/stdc++.h>
using namespace std;
#define n 4

void add_matrix(int A[][n], int B[][n], int C[][n])
{
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            C[i][j] = A[i][j] + B[i][j];
        }
    }
}

int main()
{

    int A[n][n] = {{1, 2, 3, 4},
                   {1, 2, 3, 4}};

    int B[n][n] = {{1, 2, 3, 4},
                   {1, 2, 3, 4}};

    int C[n][n];

    add_matrix(A, B, C);

    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            cout << C[i][j] << " ";
        }
        cout << endl;
    }

    return 0;
}