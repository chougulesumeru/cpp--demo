// to find largest and smallest element in an array

#include <bits/stdc++.h>
using namespace std;

int main()
{
    int arr[] = {10, 40, 30, 56, 23};

    int n = sizeof(arr) / sizeof(arr[0]);

    int min = arr[0];
    int max = arr[0];

    for (int i = 0; i < n; i++)
    {
        if (arr[i] < min)
        {
            min = arr[i];
        }

        if (arr[i] > max)
        {
            max = arr[i];
        }
    }

    cout << "thr smallest element is :-" << min << endl;
    cout << "the maximum elent of an array is :- " << max << endl;
}
