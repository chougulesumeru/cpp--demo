// arrays  are equal or not

#include <bits/stdc++.h>
using namespace std;

bool check_equal_array(int arr1[], int arr2[], int n, int m)
{
    if (n != m)
    {
        return false;
    }

    // sort the arrays

    sort(arr1, arr1 + n);
    sort(arr2, arr2 + m);

    for (int i = 0; i < n; i++)
    {
        if (arr1[i] != arr2[i])
        {
            return false;
        }
    }

    return true;
}

int main()
{
    int arr1 []= {1, 2, 3, 4, 5};
    int arr2 []= {1, 2, 3};

    int n = sizeof(arr1) / sizeof(arr1[0]);
    int m = sizeof(arr2) / sizeof(arr2[0]);

    if (check_equal_array(arr1, arr2, n, m))
    {
        cout << "equal";
    }
    else
    {
        cout << "not equal";
    }
}