/*
author:- sumeru sunil chougule
date:- 10/07/2025
To find the average of elemnt present in an array
*/

#include <bits/stdc++.h>
using namespace std;

double find_average(int arr[], int n)
{
    int sum = 0;

    for (int i = 0; i < n; i++)
    {
        sum = sum + arr[i];
    }

    return (double)sum / n; // average elemnt
}

int main()
{
    int arr[] = {1, 2, 3, 4, 5, 6};
    int n = sizeof(arr) / sizeof(arr[0]);

    cout << find_average(arr, n) << endl;

    return 0;
}