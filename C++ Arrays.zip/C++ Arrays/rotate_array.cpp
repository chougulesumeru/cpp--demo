#include <bits/stdc++.h>
using namespace std;

void rotate(int arr[], int d, int n)
{
    // temp array
    int temp[n];

    // trac the current index of an array

    int k = 0;

    for (int i = d; i < n; i++)
    {
        temp[k] = arr[i];
        k++;
    }

    for (int i = 0; i < d; i++)
    {
        temp[k] = arr[i];
        k++;
    }

    for (int i = 0; i < n; i++)
    {
        arr[i] = temp[i];
    }
}

void print_array(int arr[], int n)
{
    for (int i = 0; i < n; i++)
    {
        cout << arr[i] << " ";
    }
}

int main()
{
    int arr[] = {2, 4, 6, 8, 10};

    int n = sizeof(arr) / sizeof(arr[0]);

    int d = 3;

    rotate(arr, d, n);
    print_array(arr, n);

    return 0;
}