// to check matrix are equal or not ?

#include <bits/stdc++.h>
using namespace std;
#define n 4

int equal_matrix(int A[][n], int B[][n])
{
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            if (A[i][j] != B[i][j])
            {
                return 0;
            }
        }
    }

    return 1;
}

int main()
{
    int A[n][n] = {{1, 2, 3, 4}, {4, 5, 6, 7}};
    int B[n][n] = {{1, 2, 3, 4}, {
                                   4,
                                   5,
                                   6,
                                   7,
                               }};

    cout << equal_matrix(A, B);

    return 0;
}